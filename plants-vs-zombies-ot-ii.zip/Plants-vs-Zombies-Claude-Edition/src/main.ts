import Phaser from 'phaser';
import '@fontsource/rubik/500.css';
import '@fontsource/rubik/700.css';
import '@fontsource/rubik/900.css';
import './styles.css';
import { createGameConfig } from '@/config/gameConfig';

const game = new Phaser.Game(createGameConfig());

if (import.meta.env.DEV) {
  (window as unknown as { __game: Phaser.Game }).__game = game;
}
