import Phaser from 'phaser';
import { circle, doubleStroke, ellipse, linearGradient, makeCanvasTexture, radialGradient, roundRect, starPath } from '../canvas';
import { Tex } from '../TextureKeys';

const INK = '#3b2a18';
const WHITE = '#fff8e7';
const ICON = 44;

function filled(ctx: CanvasRenderingContext2D, fill = WHITE, width = 3): void {
  ctx.fillStyle = fill;
  ctx.fill();
  ctx.strokeStyle = INK;
  ctx.lineWidth = width;
  ctx.stroke();
}

function generateFx(tm: Phaser.Textures.TextureManager): void {
  makeCanvasTexture(tm, Tex.Fx.SunDrop, 88, 88, (ctx) => {
    const c = 44;
    ctx.fillStyle = radialGradient(ctx, c, c, 10, c, c, 44, ['rgba(255,230,90,0.75)', 'rgba(255,230,90,0)']);
    circle(ctx, c, c, 44);
    ctx.fill();
    for (let i = 0; i < 12; i++) {
      const a = (i / 12) * Math.PI * 2;
      ellipse(ctx, c + Math.cos(a) * 26, c + Math.sin(a) * 26, 11, 4.5, a);
      ctx.fillStyle = 'rgba(255,210,40,0.9)';
      ctx.fill();
    }
    circle(ctx, c, c, 21);
    ctx.fillStyle = radialGradient(ctx, c - 6, c - 7, 2, c, c, 22, ['#fffde6', '#ffe14a', '#f7a600']);
    ctx.fill();
    ctx.strokeStyle = 'rgba(220,130,0,0.75)';
    ctx.lineWidth = 2;
    ctx.stroke();
  });

  makeCanvasTexture(tm, Tex.Fx.Pea, 28, 28, (ctx) => {
    circle(ctx, 14, 14, 11);
    ctx.fillStyle = radialGradient(ctx, 10, 9, 1, 14, 14, 12, ['#dcff96', '#72d432', '#3e9a1c']);
    ctx.fill();
    ctx.strokeStyle = '#2a6e10';
    ctx.lineWidth = 2;
    ctx.stroke();
    ctx.fillStyle = 'rgba(255,255,255,0.7)';
    ellipse(ctx, 10, 9, 3.5, 2.2, -0.6);
    ctx.fill();
  });

  makeCanvasTexture(tm, Tex.Fx.SnowPea, 30, 30, (ctx) => {
    ctx.fillStyle = radialGradient(ctx, 15, 15, 8, 15, 15, 15, ['rgba(180,235,255,0.6)', 'rgba(180,235,255,0)']);
    circle(ctx, 15, 15, 15);
    ctx.fill();
    circle(ctx, 15, 15, 10.5);
    ctx.fillStyle = radialGradient(ctx, 11, 10, 1, 15, 15, 12, ['#ffffff', '#9fe0ff', '#3a9fd6']);
    ctx.fill();
    ctx.strokeStyle = '#14466a';
    ctx.lineWidth = 2;
    ctx.stroke();
    ctx.strokeStyle = 'rgba(255,255,255,0.85)';
    ctx.lineWidth = 1.5;
    ctx.beginPath();
    ctx.moveTo(15, 8);
    ctx.lineTo(15, 22);
    ctx.moveTo(9, 12);
    ctx.lineTo(21, 18);
    ctx.moveTo(21, 12);
    ctx.lineTo(9, 18);
    ctx.stroke();
  });

  makeCanvasTexture(tm, Tex.Fx.Splat, 12, 12, (ctx) => {
    circle(ctx, 6, 6, 5);
    ctx.fillStyle = '#86e046';
    ctx.fill();
  });

  makeCanvasTexture(tm, Tex.Fx.Leaf, 24, 14, (ctx) => {
    ctx.beginPath();
    ctx.moveTo(2, 7);
    ctx.bezierCurveTo(8, -1, 16, -1, 22, 7);
    ctx.bezierCurveTo(16, 15, 8, 15, 2, 7);
    ctx.closePath();
    ctx.fillStyle = linearGradient(ctx, 0, 0, 0, 14, ['#8fdc52', '#4a9e2a']);
    ctx.fill();
    ctx.strokeStyle = 'rgba(30,80,10,0.6)';
    ctx.lineWidth = 1.5;
    ctx.beginPath();
    ctx.moveTo(3, 7);
    ctx.lineTo(20, 7);
    ctx.stroke();
  });

  makeCanvasTexture(tm, Tex.Fx.Spark, 32, 32, (ctx) => {
    ctx.fillStyle = radialGradient(ctx, 16, 16, 0, 16, 16, 16, ['rgba(255,255,255,1)', 'rgba(255,250,200,0.6)', 'rgba(255,250,200,0)']);
    circle(ctx, 16, 16, 16);
    ctx.fill();
  });
}

function generateUi(tm: Phaser.Textures.TextureManager): void {
  makeCanvasTexture(tm, Tex.Ui.Star, 48, 48, (ctx) => {
    starPath(ctx, 24, 25, 21, 9.5);
    ctx.fillStyle = linearGradient(ctx, 0, 4, 0, 46, ['#fff27e', '#ffc61a', '#f09a00']);
    ctx.fill();
    ctx.strokeStyle = '#8a4e00';
    ctx.lineWidth = 3;
    ctx.stroke();
    ctx.fillStyle = 'rgba(255,255,255,0.55)';
    ellipse(ctx, 19, 17, 4, 2.5, -0.6);
    ctx.fill();
  });

  makeCanvasTexture(tm, Tex.Ui.StarEmpty, 48, 48, (ctx) => {
    starPath(ctx, 24, 25, 21, 9.5);
    ctx.fillStyle = 'rgba(70,50,30,0.35)';
    ctx.fill();
    ctx.strokeStyle = 'rgba(70,50,30,0.6)';
    ctx.lineWidth = 3;
    ctx.stroke();
  });

  makeCanvasTexture(tm, Tex.Ui.Lock, 44, 54, (ctx) => {
    ctx.beginPath();
    ctx.arc(22, 22, 12, Math.PI, 0);
    ctx.lineTo(34, 28);
    ctx.moveTo(10, 28);
    ctx.lineTo(10, 22);
    doubleStroke(ctx, INK, '#c9ced3', 10);
    roundRect(ctx, 5, 24, 34, 27, 6);
    ctx.fillStyle = linearGradient(ctx, 0, 24, 0, 51, ['#ffd970', '#e3a31f']);
    ctx.fill();
    ctx.strokeStyle = INK;
    ctx.lineWidth = 3;
    ctx.stroke();
    ctx.fillStyle = INK;
    circle(ctx, 22, 35, 4);
    ctx.fill();
    ctx.fillRect(20.5, 36, 3, 8);
  });
}

function generateIcons(tm: Phaser.Textures.TextureManager): void {
  makeCanvasTexture(tm, Tex.Icon.Back, ICON, ICON, (ctx) => {
    ctx.beginPath();
    ctx.moveTo(26, 9);
    ctx.lineTo(13, 22);
    ctx.lineTo(26, 35);
    doubleStroke(ctx, INK, WHITE, 12);
  });

  makeCanvasTexture(tm, Tex.Icon.Play, ICON, ICON, (ctx) => {
    ctx.beginPath();
    ctx.moveTo(13, 8);
    ctx.lineTo(36, 22);
    ctx.lineTo(13, 36);
    ctx.closePath();
    filled(ctx, WHITE, 3.5);
  });

  makeCanvasTexture(tm, Tex.Icon.Levels, ICON, ICON, (ctx) => {
    for (const [x, y] of [[7, 7], [23, 7], [7, 23], [23, 23]]) {
      roundRect(ctx, x, y, 14, 14, 3);
      filled(ctx, WHITE, 2.5);
    }
  });

  makeCanvasTexture(tm, Tex.Icon.Save, ICON, ICON, (ctx) => {
    roundRect(ctx, 6, 6, 32, 32, 5);
    filled(ctx, WHITE, 3);
    roundRect(ctx, 13, 6, 17, 10, 2);
    filled(ctx, '#9aa3a8', 2.5);
    roundRect(ctx, 11, 23, 22, 12, 2);
    filled(ctx, '#8fd0ff', 2.5);
  });

  makeCanvasTexture(tm, Tex.Icon.Gear, ICON, ICON, (ctx) => {
    const c = 22;
    const teeth = 8;
    ctx.beginPath();
    for (let i = 0; i < teeth; i++) {
      const a = (i / teeth) * Math.PI * 2;
      const step = Math.PI / teeth;
      ctx.lineTo(c + Math.cos(a - step * 0.5) * 18, c + Math.sin(a - step * 0.5) * 18);
      ctx.lineTo(c + Math.cos(a + step * 0.5) * 18, c + Math.sin(a + step * 0.5) * 18);
      ctx.lineTo(c + Math.cos(a + step * 0.75) * 13, c + Math.sin(a + step * 0.75) * 13);
      ctx.lineTo(c + Math.cos(a + step * 1.25) * 13, c + Math.sin(a + step * 1.25) * 13);
    }
    ctx.closePath();
    filled(ctx, WHITE, 3);
    circle(ctx, c, c, 6);
    filled(ctx, '#9aa3a8', 3);
  });

  makeCanvasTexture(tm, Tex.Icon.Plus, ICON, ICON, (ctx) => {
    ctx.beginPath();
    ctx.moveTo(22, 9);
    ctx.lineTo(22, 35);
    ctx.moveTo(9, 22);
    ctx.lineTo(35, 22);
    doubleStroke(ctx, INK, WHITE, 12);
  });

  makeCanvasTexture(tm, Tex.Icon.Trash, ICON, ICON, (ctx) => {
    ctx.beginPath();
    ctx.moveTo(11, 14);
    ctx.lineTo(13, 38);
    ctx.lineTo(31, 38);
    ctx.lineTo(33, 14);
    ctx.closePath();
    filled(ctx, WHITE, 3);
    roundRect(ctx, 7, 8, 30, 6, 3);
    filled(ctx, WHITE, 3);
    roundRect(ctx, 17, 4, 10, 5, 2);
    filled(ctx, WHITE, 2.5);
    ctx.strokeStyle = INK;
    ctx.lineWidth = 2.5;
    ctx.beginPath();
    for (const x of [18, 22, 26]) {
      ctx.moveTo(x, 19);
      ctx.lineTo(x, 33);
    }
    ctx.stroke();
  });

  makeCanvasTexture(tm, Tex.Icon.User, ICON, ICON, (ctx) => {
    ctx.beginPath();
    ctx.moveTo(7, 39);
    ctx.quadraticCurveTo(7, 24, 22, 24);
    ctx.quadraticCurveTo(37, 24, 37, 39);
    ctx.closePath();
    filled(ctx, WHITE, 3);
    circle(ctx, 22, 15, 9);
    filled(ctx, WHITE, 3);
  });

  makeCanvasTexture(tm, Tex.Icon.Check, ICON, ICON, (ctx) => {
    ctx.beginPath();
    ctx.moveTo(9, 23);
    ctx.lineTo(18, 32);
    ctx.lineTo(35, 12);
    doubleStroke(ctx, INK, WHITE, 12);
  });
}

function generateWorldIcons(tm: Phaser.Textures.TextureManager): void {
  const S = 64;
  const c = S / 2;

  makeCanvasTexture(tm, Tex.World.day, S, S, (ctx) => {
    ctx.strokeStyle = '#ffb000';
    ctx.lineWidth = 5;
    for (let i = 0; i < 8; i++) {
      const a = (i / 8) * Math.PI * 2;
      ctx.beginPath();
      ctx.moveTo(c + Math.cos(a) * 21, c + Math.sin(a) * 21);
      ctx.lineTo(c + Math.cos(a) * 29, c + Math.sin(a) * 29);
      ctx.stroke();
    }
    circle(ctx, c, c, 16);
    ctx.fillStyle = radialGradient(ctx, c - 5, c - 5, 2, c, c, 17, ['#fff7c0', '#ffd23f', '#ffa10a']);
    ctx.fill();
    ctx.strokeStyle = '#9a5a00';
    ctx.lineWidth = 2.5;
    ctx.stroke();
  });

  makeCanvasTexture(tm, Tex.World.night, S, S, (ctx) => {
    circle(ctx, c, c, 22);
    ctx.fillStyle = linearGradient(ctx, 0, 10, 0, 54, ['#fffbe0', '#e8e1a8']);
    ctx.fill();
    ctx.globalCompositeOperation = 'destination-out';
    circle(ctx, c + 12, c - 8, 19);
    ctx.fill();
    ctx.globalCompositeOperation = 'source-over';
    ctx.fillStyle = '#fff6b0';
    for (const [x, y, r] of [[46, 34, 5], [52, 50, 3.5], [38, 12, 3]]) {
      starPath(ctx, x, y, r, r * 0.45);
      ctx.fill();
    }
  });

  makeCanvasTexture(tm, Tex.World.pool, S, S, (ctx) => {
    for (let i = 0; i < 4; i++) {
      ctx.beginPath();
      ctx.arc(c, c, 21, (i * Math.PI) / 2, ((i + 1) * Math.PI) / 2);
      ctx.strokeStyle = i % 2 === 0 ? '#e8402c' : '#ffffff';
      ctx.lineWidth = 12;
      ctx.lineCap = 'butt';
      ctx.stroke();
    }
    ctx.strokeStyle = '#3b2a18';
    ctx.lineWidth = 2.5;
    circle(ctx, c, c, 27);
    ctx.stroke();
    circle(ctx, c, c, 15);
    ctx.stroke();
  });

  makeCanvasTexture(tm, Tex.World.fog, S, S, (ctx) => {
    const puffs = [[20, 36, 11], [32, 28, 14], [45, 36, 11], [32, 40, 10]];
    ctx.beginPath();
    for (const [x, y, r] of puffs) {
      ctx.moveTo(x + r, y);
      ctx.arc(x, y, r, 0, Math.PI * 2);
    }
    ctx.fillStyle = linearGradient(ctx, 0, 14, 0, 50, ['#f3f6fa', '#b7c3d1']);
    ctx.fill();
    ctx.strokeStyle = 'rgba(255,255,255,0.8)';
    ctx.lineWidth = 3;
    ctx.beginPath();
    ctx.moveTo(10, 52);
    ctx.lineTo(54, 52);
    ctx.moveTo(16, 58);
    ctx.lineTo(48, 58);
    ctx.stroke();
  });

  makeCanvasTexture(tm, Tex.World.roof, S, S, (ctx) => {
    ctx.fillStyle = '#8a8f96';
    ctx.fillRect(40, 10, 9, 18);
    ctx.beginPath();
    ctx.moveTo(6, 40);
    ctx.lineTo(32, 14);
    ctx.lineTo(58, 40);
    ctx.closePath();
    ctx.fillStyle = linearGradient(ctx, 0, 14, 0, 40, ['#e0633f', '#a8341c']);
    ctx.fill();
    ctx.strokeStyle = '#4a1508';
    ctx.lineWidth = 3;
    ctx.stroke();
    ctx.fillStyle = '#f2e6c9';
    ctx.fillRect(14, 40, 36, 16);
    ctx.strokeRect(14, 40, 36, 16);
    ctx.fillStyle = '#7fc8ff';
    ctx.fillRect(27, 44, 10, 8);
  });
}

export function generateIconTextures(tm: Phaser.Textures.TextureManager): void {
  generateFx(tm);
  generateUi(tm);
  generateIcons(tm);
  generateWorldIcons(tm);
}
