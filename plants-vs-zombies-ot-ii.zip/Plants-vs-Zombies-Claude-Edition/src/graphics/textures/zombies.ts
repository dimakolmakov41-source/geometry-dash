import Phaser from 'phaser';
import { circle, ellipse, linearGradient, makeCanvasTexture, radialGradient, roundRect } from '../canvas';
import { Tex } from '../TextureKeys';

/**
 * Точки крепления частей зомби (суставы) в долях текстуры:
 * голова вращается вокруг шеи, руки — вокруг плеча, ноги — вокруг бедра.
 */
export const ZOMBIE_ORIGIN = {
  head: { x: 53 / 92, y: 88 / 92 },
  torso: { x: 0.5, y: 0.5 },
  arm: { x: 0.5, y: 0.06 },
  leg: { x: 18 / 34, y: 0.04 },
} as const;

const SKIN = ['#d2dfb6', '#9fb581', '#71885a'];
const OUTLINE = '#2f3a22';
const CLOTH_OUTLINE = '#2e2010';

function zigzag(ctx: CanvasRenderingContext2D, fromX: number, toX: number, y: number, depth: number, step: number): void {
  const dir = toX > fromX ? 1 : -1;
  let down = true;
  for (let x = fromX; dir > 0 ? x < toX : x > toX; x += step * dir) {
    ctx.lineTo(x, down ? y + depth : y);
    down = !down;
  }
  ctx.lineTo(toX, y);
}

function drawHead(ctx: CanvasRenderingContext2D): void {
  // шея
  roundRect(ctx, 44, 62, 18, 30, 5);
  ctx.fillStyle = SKIN[2];
  ctx.fill();
  ctx.strokeStyle = OUTLINE;
  ctx.lineWidth = 2.5;
  ctx.stroke();

  // ухо (за головой)
  ellipse(ctx, 84, 44, 7, 11);
  ctx.fillStyle = SKIN[1];
  ctx.fill();
  ctx.stroke();

  // контур черепа и челюсти одним силуэтом: сначала толстая обводка, затем заливка поверх
  const cranium = () => ellipse(ctx, 50, 38, 35, 33);
  const jaw = () => ellipse(ctx, 34, 60, 22, 15);
  ctx.strokeStyle = OUTLINE;
  ctx.lineWidth = 6;
  cranium();
  ctx.stroke();
  jaw();
  ctx.stroke();
  ctx.fillStyle = radialGradient(ctx, 38, 24, 4, 48, 42, 48, SKIN);
  cranium();
  ctx.fill();
  jaw();
  ctx.fill();

  // пятна и тени
  ctx.fillStyle = 'rgba(80,100,55,0.35)';
  for (const [x, y, r] of [[64, 20, 4], [72, 34, 3], [60, 54, 3.5], [44, 12, 2.5]]) {
    circle(ctx, x, y, r);
    ctx.fill();
  }
  ctx.fillStyle = 'rgba(255,255,255,0.18)';
  ellipse(ctx, 40, 16, 14, 6, -0.3);
  ctx.fill();

  // впалые глазницы
  ctx.fillStyle = 'rgba(70,55,85,0.38)';
  ellipse(ctx, 29, 38, 16, 14);
  ctx.fill();
  ellipse(ctx, 56, 36, 12, 11);
  ctx.fill();

  // глаза: переднее большое с опущенным веком, заднее поменьше
  for (const [x, y, r, px, py, pr] of [
    [29, 38, 12, 25, 40, 3.6],
    [56, 36, 9, 53, 38, 3],
  ]) {
    circle(ctx, x, y, r);
    ctx.fillStyle = '#f5f2e4';
    ctx.fill();
    ctx.strokeStyle = OUTLINE;
    ctx.lineWidth = 2.5;
    ctx.stroke();
    ctx.fillStyle = '#141414';
    circle(ctx, px, py, pr);
    ctx.fill();
  }
  ctx.save();
  circle(ctx, 29, 38, 12);
  ctx.clip();
  ctx.fillStyle = SKIN[1];
  ctx.fillRect(14, 22, 32, 10);
  ctx.restore();
  ctx.strokeStyle = OUTLINE;
  ctx.lineWidth = 2.5;
  ctx.beginPath();
  ctx.moveTo(17, 31);
  ctx.lineTo(41, 31);
  ctx.stroke();

  // надбровье и нос
  ctx.lineWidth = 3;
  ctx.beginPath();
  ctx.moveTo(14, 25);
  ctx.quadraticCurveTo(28, 19, 42, 25);
  ctx.moveTo(18, 47);
  ctx.quadraticCurveTo(13, 51, 19, 53);
  ctx.stroke();

  // разинутый рот с парой зубов
  ctx.beginPath();
  ctx.moveTo(14, 60);
  ctx.quadraticCurveTo(28, 56, 45, 60);
  ctx.lineTo(43, 71);
  ctx.quadraticCurveTo(29, 77, 17, 71);
  ctx.closePath();
  ctx.fillStyle = '#3a1414';
  ctx.fill();
  ctx.strokeStyle = OUTLINE;
  ctx.lineWidth = 2;
  ctx.stroke();
  ctx.fillStyle = '#efe9cf';
  ctx.fillRect(21, 59, 6, 6);
  ctx.fillRect(33, 58, 6, 5);
  ctx.fillRect(27, 67, 5, 5);

  // редкие волосы
  ctx.strokeStyle = '#26261d';
  ctx.lineWidth = 3;
  for (const [x0, cx, x1, y1] of [[42, 34, 30, 2], [54, 54, 62, 0], [64, 74, 78, 6]]) {
    ctx.beginPath();
    ctx.moveTo(x0, 8);
    ctx.quadraticCurveTo(cx, -2, x1, y1 + 4);
    ctx.stroke();
  }
}

function drawSuitTorso(ctx: CanvasRenderingContext2D): void {
  ctx.beginPath();
  ctx.moveTo(12, 28);
  ctx.quadraticCurveTo(12, 8, 34, 6);
  ctx.lineTo(56, 6);
  ctx.quadraticCurveTo(78, 8, 78, 28);
  ctx.lineTo(84, 94);
  zigzag(ctx, 84, 6, 94, 7, 8);
  ctx.lineTo(8, 94);
  ctx.closePath();
  ctx.fillStyle = linearGradient(ctx, 0, 6, 0, 100, ['#93704a', '#5c4426']);
  ctx.fill();
  ctx.strokeStyle = CLOTH_OUTLINE;
  ctx.lineWidth = 3;
  ctx.stroke();

  // рубашка, воротник, галстук
  ctx.beginPath();
  ctx.moveTo(32, 6);
  ctx.lineTo(58, 6);
  ctx.lineTo(45, 56);
  ctx.closePath();
  ctx.fillStyle = '#ece6d3';
  ctx.fill();
  ctx.fillStyle = '#ffffff';
  for (const [x0, x1, x2] of [[32, 44, 38], [58, 46, 52]]) {
    ctx.beginPath();
    ctx.moveTo(x0, 5);
    ctx.lineTo(x1, 8);
    ctx.lineTo(x2, 16);
    ctx.closePath();
    ctx.fill();
  }
  ctx.beginPath();
  ctx.moveTo(42, 10);
  ctx.lineTo(48, 10);
  ctx.lineTo(52, 44);
  ctx.lineTo(45, 54);
  ctx.lineTo(38, 44);
  ctx.closePath();
  ctx.fillStyle = '#c42a2a';
  ctx.fill();
  ctx.strokeStyle = '#6e1010';
  ctx.lineWidth = 2;
  ctx.stroke();

  // лацканы, пуговицы, карман, заплатка
  ctx.strokeStyle = CLOTH_OUTLINE;
  ctx.lineWidth = 2.5;
  ctx.beginPath();
  ctx.moveTo(32, 6);
  ctx.lineTo(40, 44);
  ctx.moveTo(58, 6);
  ctx.lineTo(50, 44);
  ctx.moveTo(16, 60);
  ctx.lineTo(32, 60);
  ctx.stroke();
  ctx.fillStyle = '#2e2010';
  circle(ctx, 40, 66, 2.5);
  ctx.fill();
  circle(ctx, 40, 80, 2.5);
  ctx.fill();
  roundRect(ctx, 58, 60, 16, 14, 2);
  ctx.fillStyle = '#7a8a5a';
  ctx.fill();
  ctx.lineWidth = 1.5;
  ctx.setLineDash([3, 3]);
  ctx.stroke();
  ctx.setLineDash([]);
  ctx.fillStyle = 'rgba(0,0,0,0.15)';
  ctx.fillRect(12, 28, 8, 64);
}

function drawAthleteTorso(ctx: CanvasRenderingContext2D): void {
  ctx.beginPath();
  ctx.moveTo(18, 22);
  ctx.quadraticCurveTo(20, 8, 34, 6);
  ctx.lineTo(56, 6);
  ctx.quadraticCurveTo(70, 8, 72, 22);
  ctx.lineTo(78, 96);
  ctx.lineTo(12, 96);
  ctx.closePath();
  ctx.fillStyle = linearGradient(ctx, 0, 6, 0, 96, ['#ffffff', '#d9d9cf']);
  ctx.fill();
  ctx.save();
  ctx.clip();
  ctx.fillStyle = '#d0332e';
  ctx.fillRect(12, 0, 10, 100);
  ctx.fillRect(68, 0, 10, 100);
  ctx.fillRect(0, 84, 90, 12);
  ctx.restore();
  ctx.strokeStyle = CLOTH_OUTLINE;
  ctx.lineWidth = 3;
  ctx.stroke();
  // вырез и номер
  ctx.beginPath();
  ctx.arc(45, 6, 12, 0, Math.PI);
  ctx.fillStyle = SKIN[2];
  ctx.fill();
  ctx.stroke();
  roundRect(ctx, 30, 36, 30, 28, 4);
  ctx.fillStyle = '#fffbe9';
  ctx.fill();
  ctx.lineWidth = 2;
  ctx.stroke();
  ctx.fillStyle = '#2b2b2b';
  ctx.font = '900 20px Rubik, sans-serif';
  ctx.textAlign = 'center';
  ctx.fillText('13', 45, 57);
}

function drawArm(ctx: CanvasRenderingContext2D, sleeve: boolean): void {
  // предплечье и кисть
  roundRect(ctx, 9, 40, 12, 36, 5);
  ctx.fillStyle = SKIN[1];
  ctx.fill();
  ctx.strokeStyle = OUTLINE;
  ctx.lineWidth = 2;
  ctx.stroke();
  ctx.fillStyle = SKIN[1];
  for (const [x, h] of [[9, 9], [14, 10], [19, 8]]) {
    roundRect(ctx, x, 80, 4.5, h, 2);
    ctx.fill();
    ctx.stroke();
  }
  circle(ctx, 15, 80, 7.5);
  ctx.fill();
  ctx.stroke();

  if (sleeve) {
    ctx.beginPath();
    ctx.moveTo(4, 9);
    ctx.quadraticCurveTo(4, 0, 15, 0);
    ctx.quadraticCurveTo(26, 0, 26, 9);
    ctx.lineTo(24, 46);
    zigzag(ctx, 24, 6, 46, 5, 4.5);
    ctx.lineTo(6, 46);
    ctx.closePath();
    ctx.fillStyle = linearGradient(ctx, 4, 0, 26, 0, ['#93704a', '#6a4f2c']);
    ctx.fill();
    ctx.strokeStyle = CLOTH_OUTLINE;
    ctx.lineWidth = 2.5;
    ctx.stroke();
  } else {
    roundRect(ctx, 7, 0, 16, 46, 7);
    ctx.fillStyle = SKIN[1];
    ctx.fill();
    ctx.strokeStyle = OUTLINE;
    ctx.stroke();
  }
}

function drawLeg(ctx: CanvasRenderingContext2D, athlete: boolean): void {
  if (athlete) {
    roundRect(ctx, 10, 22, 15, 34, 6);
    ctx.fillStyle = SKIN[1];
    ctx.fill();
    ctx.strokeStyle = OUTLINE;
    ctx.lineWidth = 2;
    ctx.stroke();
    roundRect(ctx, 6, 0, 24, 28, 7);
    ctx.fillStyle = linearGradient(ctx, 6, 0, 30, 0, ['#d93b35', '#a8241f']);
    ctx.fill();
    ctx.strokeStyle = CLOTH_OUTLINE;
    ctx.lineWidth = 2.5;
    ctx.stroke();
    ctx.fillStyle = '#f4f4ee';
    ctx.fillRect(10, 54, 15, 16);
    ctx.fillStyle = '#d0332e';
    ctx.fillRect(10, 58, 15, 3);
    ellipse(ctx, 13, 77, 14, 7);
    ctx.fillStyle = '#efefe8';
    ctx.fill();
    ctx.strokeStyle = '#3a3a3a';
    ctx.lineWidth = 2;
    ctx.stroke();
    ctx.strokeStyle = '#d0332e';
    ctx.beginPath();
    ctx.moveTo(4, 77);
    ctx.lineTo(20, 74);
    ctx.stroke();
    return;
  }
  roundRect(ctx, 12, 58, 12, 14, 3);
  ctx.fillStyle = SKIN[2];
  ctx.fill();
  ctx.beginPath();
  ctx.moveTo(9, 4);
  ctx.quadraticCurveTo(9, 0, 18, 0);
  ctx.quadraticCurveTo(27, 0, 27, 4);
  ctx.lineTo(28, 60);
  zigzag(ctx, 28, 8, 60, 5, 4);
  ctx.lineTo(8, 60);
  ctx.closePath();
  ctx.fillStyle = linearGradient(ctx, 8, 0, 28, 0, ['#6e5c49', '#473a2d']);
  ctx.fill();
  ctx.strokeStyle = CLOTH_OUTLINE;
  ctx.lineWidth = 2.5;
  ctx.stroke();
  ctx.beginPath();
  ctx.moveTo(26, 70);
  ctx.lineTo(26, 80);
  ctx.lineTo(2, 81);
  ctx.quadraticCurveTo(-1, 74, 8, 71);
  ctx.closePath();
  ctx.fillStyle = '#3a2a1e';
  ctx.fill();
  ctx.strokeStyle = '#140e09';
  ctx.lineWidth = 2;
  ctx.stroke();
  ctx.fillStyle = 'rgba(255,255,255,0.18)';
  ctx.fillRect(6, 72, 12, 2);
}

export function generateZombieTextures(tm: Phaser.Textures.TextureManager): void {
  makeCanvasTexture(tm, Tex.Zombie.Head, 92, 92, drawHead);
  makeCanvasTexture(tm, Tex.Zombie.Torso, 90, 104, drawSuitTorso);
  makeCanvasTexture(tm, Tex.Zombie.TorsoAthlete, 90, 104, drawAthleteTorso);
  makeCanvasTexture(tm, Tex.Zombie.Arm, 30, 92, (ctx) => drawArm(ctx, true));
  makeCanvasTexture(tm, Tex.Zombie.ArmBare, 30, 92, (ctx) => drawArm(ctx, false));
  makeCanvasTexture(tm, Tex.Zombie.Leg, 34, 86, (ctx) => drawLeg(ctx, false));
  makeCanvasTexture(tm, Tex.Zombie.LegAthlete, 34, 86, (ctx) => drawLeg(ctx, true));

  makeCanvasTexture(tm, Tex.Zombie.Headband, 80, 22, (ctx) => {
    roundRect(ctx, 3, 4, 74, 14, 7);
    ctx.fillStyle = '#d0332e';
    ctx.fill();
    ctx.strokeStyle = '#5a0a0a';
    ctx.lineWidth = 2.5;
    ctx.stroke();
    ctx.fillStyle = '#ffffff';
    ctx.fillRect(6, 9, 68, 3);
  });

  makeCanvasTexture(tm, Tex.Zombie.Pole, 190, 12, (ctx) => {
    roundRect(ctx, 2, 2, 186, 8, 4);
    ctx.fillStyle = linearGradient(ctx, 0, 2, 0, 10, ['#f2d16b', '#b88a2a']);
    ctx.fill();
    ctx.strokeStyle = '#5a3d0a';
    ctx.lineWidth = 2;
    ctx.stroke();
    ctx.fillStyle = '#3b2a18';
    ctx.fillRect(110, 2, 18, 8);
  });
}
