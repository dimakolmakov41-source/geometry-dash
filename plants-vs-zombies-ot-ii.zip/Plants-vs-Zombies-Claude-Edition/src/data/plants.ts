export type PlantId =
  | 'peashooter'
  | 'sunflower'
  | 'cherrybomb'
  | 'wallnut'
  | 'potatomine'
  | 'snowpea'
  | 'chomper'
  | 'repeater'
  | 'puffshroom'
  | 'sunshroom'
  | 'fumeshroom'
  | 'gravebuster'
  | 'hypnoshroom'
  | 'scaredyshroom'
  | 'iceshroom'
  | 'doomshroom'
  | 'lilypad'
  | 'squash'
  | 'threepeater'
  | 'tanglekelp'
  | 'jalapeno'
  | 'spikeweed'
  | 'torchwood'
  | 'tallnut';

/** Описание растения. Боевые параметры будут расширены на этапе геймплея. */
export interface PlantDef {
  id: PlantId;
  name: string;
  cost: number;
  cooldownSec: number;
  description: string;
}

const plant = (id: PlantId, name: string, cost: number, cooldownSec: number, description: string): PlantDef => ({
  id,
  name,
  cost,
  cooldownSec,
  description,
});

export const PLANTS: Record<PlantId, PlantDef> = {
  peashooter: plant('peashooter', 'Горохострел', 100, 7.5, 'Стреляет горошинами по зомби'),
  sunflower: plant('sunflower', 'Подсолнух', 50, 7.5, 'Даёт дополнительное солнце'),
  cherrybomb: plant('cherrybomb', 'Вишнёвая бомба', 150, 50, 'Взрывает всех зомби вокруг'),
  wallnut: plant('wallnut', 'Стенорех', 50, 30, 'Крепкий орех, задерживает зомби'),
  potatomine: plant('potatomine', 'Картофельная мина', 25, 30, 'Взрывается при касании'),
  snowpea: plant('snowpea', 'Снежный горох', 175, 7.5, 'Замедляет зомби ледяным горохом'),
  chomper: plant('chomper', 'Кусачка', 150, 7.5, 'Проглатывает зомби целиком'),
  repeater: plant('repeater', 'Повторитель', 200, 7.5, 'Стреляет двумя горошинами'),
  puffshroom: plant('puffshroom', 'Пуф-гриб', 0, 7.5, 'Бесплатный ночной стрелок'),
  sunshroom: plant('sunshroom', 'Солнце-гриб', 25, 7.5, 'Ночной источник солнца'),
  fumeshroom: plant('fumeshroom', 'Дым-гриб', 75, 7.5, 'Пробивает дымом насквозь'),
  gravebuster: plant('gravebuster', 'Могилоед', 75, 7.5, 'Съедает надгробия'),
  hypnoshroom: plant('hypnoshroom', 'Гипно-гриб', 75, 30, 'Переманивает зомби на свою сторону'),
  scaredyshroom: plant('scaredyshroom', 'Трусо-гриб', 25, 7.5, 'Дальнобойный, но пугливый'),
  iceshroom: plant('iceshroom', 'Ледо-гриб', 75, 50, 'Замораживает всех зомби'),
  doomshroom: plant('doomshroom', 'Гриб судьбы', 125, 50, 'Огромный взрыв'),
  lilypad: plant('lilypad', 'Кувшинка', 25, 7.5, 'Позволяет сажать растения на воде'),
  squash: plant('squash', 'Тыква-давилка', 50, 30, 'Расплющивает ближайшего зомби'),
  threepeater: plant('threepeater', 'Трёхствол', 325, 7.5, 'Стреляет по трём линиям'),
  tanglekelp: plant('tanglekelp', 'Водоросль-душитель', 25, 30, 'Утягивает зомби под воду'),
  jalapeno: plant('jalapeno', 'Халапеньо', 125, 50, 'Сжигает целую линию'),
  spikeweed: plant('spikeweed', 'Колючка', 100, 7.5, 'Ранит наступивших зомби'),
  torchwood: plant('torchwood', 'Огнепень', 175, 7.5, 'Поджигает горошины'),
  tallnut: plant('tallnut', 'Высокорех', 125, 30, 'Высокая и прочная стена'),
};

export const STARTER_PLANTS: PlantId[] = ['peashooter'];
