import type { ZombieId } from './zombies';

export interface WaveDef {
  zombies: ZombieId[];
  /** Огромная волна: предупреждение и знаменосец впереди. */
  flag?: boolean;
}

/** Сценарий уровня: какие линии активны, сколько солнца и какие волны. */
export interface LevelScript {
  /** Индексы активных линий (0–4). На неактивных лежит земля, сажать нельзя. */
  rows: number[];
  startSun: number;
  /** Секунд до первой волны. */
  firstWaveDelay: number;
  /** Базовая пауза между волнами (растёт с размером волны). */
  waveInterval: number;
  /** Солнце с неба: первое через `first` секунд, затем каждые min–max секунд. */
  skySun: { first: number; min: number; max: number };
  waves: WaveDef[];
}

const many = (count: number, type: ZombieId = 'basic'): ZombieId[] => Array.from({ length: count }, () => type);
const wave = (...zombies: ZombieId[]): WaveDef => ({ zombies });
const flagWave = (...zombies: ZombieId[]): WaveDef => ({ zombies: ['flag', ...zombies], flag: true });

export const LEVEL_SCRIPTS: Record<string, LevelScript> = {
  // Обучение: одна линия, только горохострел.
  '1-1': {
    rows: [2],
    startSun: 150,
    firstWaveDelay: 20,
    waveInterval: 18,
    skySun: { first: 3, min: 6, max: 9 },
    waves: [wave('basic'), wave('basic'), wave(...many(2)), wave('basic'), wave(...many(2)), flagWave(...many(3))],
  },
  // Три линии и подсолнухи — учимся копить солнце.
  '1-2': {
    rows: [1, 2, 3],
    startSun: 50,
    firstWaveDelay: 24,
    waveInterval: 20,
    skySun: { first: 4, min: 7, max: 11 },
    waves: [
      wave('basic'),
      wave('basic'),
      wave(...many(2)),
      wave('basic'),
      wave(...many(2)),
      wave(...many(3)),
      wave(...many(2)),
      flagWave(...many(5)),
    ],
  },
  // Появляются зомби в конусах и вишнёвая бомба.
  '1-3': {
    rows: [1, 2, 3],
    startSun: 50,
    firstWaveDelay: 22,
    waveInterval: 20,
    skySun: { first: 4, min: 7, max: 11 },
    waves: [
      wave('basic'),
      wave(...many(2)),
      wave('conehead'),
      wave(...many(3)),
      flagWave('basic', 'conehead', 'basic', 'basic'),
      wave('basic', 'conehead'),
      wave(...many(2), 'conehead'),
      wave('conehead', ...many(3)),
      flagWave('conehead', 'conehead', ...many(4)),
    ],
  },
  // Все пять линий.
  '1-4': fullLawn(22, [
    wave('basic'),
    wave('basic'),
    wave(...many(2)),
    wave('conehead'),
    wave(...many(3)),
    flagWave('basic', 'basic', 'conehead', 'basic'),
    wave('conehead', 'basic'),
    wave(...many(2), 'conehead'),
    wave('conehead', 'conehead', 'basic'),
    wave(...many(3), 'conehead'),
    flagWave('conehead', 'conehead', ...many(4)),
  ]),
  '1-5': fullLawn(22, [
    wave('basic'),
    wave(...many(2)),
    wave('conehead'),
    wave(...many(2)),
    wave('conehead', 'basic'),
    wave(...many(3)),
    flagWave('conehead', ...many(3), 'conehead'),
    wave('conehead', 'conehead'),
    wave(...many(2), 'conehead', 'basic'),
    wave('conehead', 'basic', 'conehead'),
    flagWave(...many(3, 'conehead'), ...many(4)),
  ]),
  // Появляются прыгуны с шестом.
  '1-6': fullLawn(22, [
    wave('basic'),
    wave('polevaulter'),
    wave(...many(2)),
    wave('polevaulter', 'basic'),
    wave('conehead', 'basic'),
    flagWave('polevaulter', 'basic', 'basic', 'conehead'),
    wave('polevaulter', 'conehead'),
    wave(...many(2), 'polevaulter'),
    wave('conehead', 'polevaulter', ...many(2)),
    wave('polevaulter', 'polevaulter', 'conehead'),
    flagWave('conehead', 'conehead', 'polevaulter', 'polevaulter', ...many(3)),
  ]),
  '1-7': fullLawn(21, [
    wave('basic'),
    wave('basic', 'conehead'),
    wave('polevaulter'),
    wave(...many(2), 'conehead'),
    wave('polevaulter', 'conehead'),
    wave(...many(3), 'polevaulter'),
    flagWave('conehead', 'conehead', 'polevaulter', 'basic', 'basic'),
    wave('conehead', 'polevaulter', 'basic'),
    wave(...many(2), 'conehead', 'conehead'),
    wave('polevaulter', 'polevaulter', 'basic'),
    wave(...many(3, 'conehead'), 'basic'),
    flagWave('polevaulter', 'polevaulter', 'conehead', 'conehead', ...many(4)),
  ]),
  // Появляются зомби с ведром.
  '1-8': fullLawn(21, [
    wave('basic'),
    wave(...many(2)),
    wave('buckethead'),
    wave('conehead', 'basic'),
    wave('basic', 'polevaulter', 'basic'),
    wave('buckethead', 'basic'),
    flagWave('buckethead', 'conehead', 'basic', 'basic', 'polevaulter'),
    wave('conehead', 'conehead', 'basic'),
    wave('buckethead', 'polevaulter'),
    wave(...many(2), 'conehead', 'conehead'),
    wave('buckethead', 'buckethead', 'basic'),
    flagWave('buckethead', 'buckethead', 'conehead', 'conehead', 'polevaulter', ...many(3)),
  ]),
  '1-9': fullLawn(21, [
    wave(...many(2)),
    wave('conehead'),
    wave('polevaulter', 'basic'),
    wave('buckethead'),
    wave('conehead', 'conehead', 'basic'),
    wave('polevaulter', 'polevaulter'),
    flagWave('buckethead', 'conehead', 'conehead', 'basic', 'basic', 'polevaulter'),
    wave('buckethead', 'basic', 'basic'),
    wave('conehead', 'conehead', 'polevaulter'),
    wave('buckethead', 'conehead', ...many(2)),
    wave('polevaulter', 'polevaulter', 'conehead', 'conehead'),
    wave('buckethead', 'buckethead', 'conehead'),
    flagWave('buckethead', 'buckethead', 'conehead', 'conehead', 'polevaulter', 'polevaulter', ...many(3)),
  ]),
  // Финал дня: три огромные волны.
  '1-10': fullLawn(20, [
    wave(...many(2)),
    wave('conehead'),
    wave('polevaulter', 'basic'),
    wave('conehead', 'conehead'),
    wave('buckethead', 'basic'),
    flagWave('conehead', 'conehead', 'polevaulter', 'basic', 'basic'),
    wave('buckethead', 'conehead'),
    wave('polevaulter', 'polevaulter', 'basic'),
    wave(...many(3, 'conehead')),
    wave('buckethead', 'buckethead'),
    flagWave('buckethead', 'conehead', 'conehead', 'polevaulter', 'polevaulter', 'basic'),
    wave('buckethead', 'polevaulter', 'conehead'),
    wave(...many(3, 'conehead'), 'basic'),
    wave('buckethead', 'buckethead', 'polevaulter'),
    flagWave('buckethead', 'buckethead', ...many(3, 'conehead'), 'polevaulter', 'polevaulter', ...many(3)),
  ]),
};

/** Стандартный дневной уровень на всех пяти линиях. */
function fullLawn(waveInterval: number, waves: WaveDef[]): LevelScript {
  return {
    rows: [0, 1, 2, 3, 4],
    startSun: 50,
    firstWaveDelay: 25,
    waveInterval,
    skySun: { first: 4, min: 7, max: 10 },
    waves,
  };
}

export function getLevelScript(levelId: string): LevelScript | undefined {
  return LEVEL_SCRIPTS[levelId];
}

export function hasLevelScript(levelId: string): boolean {
  return levelId in LEVEL_SCRIPTS;
}

/** Типы зомби, которые встретятся на уровне (для превью перед боем). */
export function scriptZombieTypes(script: LevelScript): ZombieId[] {
  return [...new Set(script.waves.flatMap((w) => w.zombies))];
}
