import { CENTER_X } from '@/config/constants';
import { SceneKeys } from '@/core/SceneKeys';
import { saves } from '@/core/SaveManager';
import { Tex } from '@/graphics/TextureKeys';
import { t } from '@/i18n/ru';
import { RoundButton } from '@/ui/Button';
import { openCreateProfileDialog } from '@/ui/dialogs';
import { Modal } from '@/ui/Modal';
import { showToast } from '@/ui/Toast';
import { textStyle } from '@/ui/theme';
import { MenuScene } from './MenuScene';
import { SaveSlotCard } from './components/SaveSlotCard';

const CARD_DX = 390;
const CARD_Y = 400;

export class SavesScene extends MenuScene {
  private cards: SaveSlotCard[] = [];

  constructor() {
    super(SceneKeys.Saves);
  }

  create(): void {
    this.cards = [];
    this.initMenu('day');
    const back = new RoundButton(this, 60, 56, Tex.Icon.Back).onClick(() => this.back());
    const title = this.add.text(CENTER_X, 56, t.saves.title, textStyle(46)).setOrigin(0.5);
    this.root.add([back, title]);
    this.buildCards(true);
  }

  protected override onBack(): void {
    this.back();
  }

  private buildCards(intro: boolean): void {
    for (const card of this.cards) card.destroy();
    const activeSlot = saves.activeSlotIndex;
    this.cards = saves.list().map((save, slot) => {
      const card = new SaveSlotCard(this, CENTER_X + (slot - 1) * CARD_DX, CARD_Y, slot, save, slot === activeSlot, {
        onPlay: () => this.play(slot),
        onCreate: () => openCreateProfileDialog(this, slot, () => this.buildCards(false)),
        onDelete: () => this.confirmDelete(slot),
      });
      this.root.add(card);
      if (intro) {
        card.y = CARD_Y + 120;
        card.setAlpha(0);
        this.tweens.add({ targets: card, y: CARD_Y, alpha: 1, delay: 120 + slot * 110, duration: 520, ease: 'Back.easeOut' });
      } else {
        card.setScale(0.94);
        this.tweens.add({ targets: card, scale: 1, duration: 260, ease: 'Back.easeOut' });
      }
      return card;
    });
  }

  private play(slot: number): void {
    if (saves.activeSlotIndex !== slot) {
      saves.setActive(slot);
      const save = saves.active;
      if (save) showToast(this, t.saves.selected(save.name));
    }
    this.goTo(SceneKeys.LevelSelect);
  }

  private confirmDelete(slot: number): void {
    const save = saves.load(slot);
    if (!save) return;
    Modal.open(this, {
      title: t.saves.deleteTitle,
      message: t.saves.deleteMessage(save.name),
      buttons: [
        { label: t.common.cancel },
        {
          label: t.common.delete,
          variant: 'red',
          onClick: () => {
            saves.delete(slot);
            showToast(this, t.saves.deleted);
            this.buildCards(false);
          },
        },
      ],
    });
  }
}
