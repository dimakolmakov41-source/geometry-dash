import Phaser from 'phaser';
import { GAME_HEIGHT, GAME_WIDTH } from '@/config/constants';
import { SceneKeys } from '@/core/SceneKeys';
import { audio } from '@/audio/AudioManager';
import { Tex } from '@/graphics/TextureKeys';
import { Banners } from '@/game/hud/Banners';
import { HintRibbon } from '@/game/hud/HintRibbon';
import { PauseMenu } from '@/game/hud/PauseMenu';
import { ResultPanel } from '@/game/hud/ResultPanel';
import { SeedBank } from '@/game/hud/SeedBank';
import { SpeedControls } from '@/game/hud/SpeedControls';
import { WaveMeter } from '@/game/hud/WaveMeter';
import type { LevelSession, Phase, SessionRequest } from '@/game/LevelSession';
import { t } from '@/i18n/ru';
import { RoundButton } from '@/ui/Button';
import { textStyle } from '@/ui/theme';
import { BaseScene } from './BaseScene';

export interface GameHudData {
  session: LevelSession;
}

/**
 * Интерфейс боя поверх GameScene. Отдельная сцена позволяет ставить игру на паузу
 * (scene.pause), не замораживая сам интерфейс, и ускорять игру, не ускоряя анимации кнопок.
 */
export class GameHudScene extends BaseScene {
  private session!: LevelSession;
  private bank!: SeedBank;
  private speed!: SpeedControls;
  private pauseButton!: RoundButton;
  private meter!: WaveMeter;
  private banners!: Banners;
  private hint!: HintRibbon;
  private pauseMenu: PauseMenu | null = null;
  private hudShown = false;

  constructor() {
    super(SceneKeys.GameHud);
  }

  create(data: GameHudData): void {
    this.session = data.session;
    this.pauseMenu = null;
    this.hudShown = false;

    this.bank = new SeedBank(this, this.session);
    this.bank.y = -130;
    this.speed = new SpeedControls(this, GAME_WIDTH - 170, 52, this.session).setAlpha(0);
    this.pauseButton = new RoundButton(this, GAME_WIDTH - 46, 50, Tex.Icon.Pause, { size: 56 }).onClick(() => this.togglePause());
    this.pauseButton.setAlpha(0);
    this.meter = new WaveMeter(this, GAME_WIDTH - 196, GAME_HEIGHT - 26, this.session).setAlpha(0);
    const label = this.add.text(88, GAME_HEIGHT - 12, t.game.level(this.session.level.id), textStyle(18)).setOrigin(0.5, 1);
    label.setAlpha(0);
    this.banners = new Banners(this);
    this.hint = new HintRibbon(this, 560, GAME_HEIGHT - 40);

    const s = this.session;
    s.on('banner', (kind) => {
      if (kind === 'ready') this.showHud([label]);
      this.banners.show(kind);
    });
    s.on('phase-changed', (phase) => this.onPhase(phase));
    s.on('hint', (text) => this.hint.show(text));
    s.on('result', (result) => {
      this.time.delayedCall(result.victory ? 400 : 0, () => new ResultPanel(this, result, (a) => this.request(a)));
    });

    this.input.keyboard?.on('keydown', this.onKey, this);
  }

  update(_time: number, deltaMs: number): void {
    const dt = deltaMs / 1000;
    this.bank.refresh(dt);
    this.meter.refresh(dt);
  }

  private showHud(extra: Phaser.GameObjects.GameObject[]): void {
    if (this.hudShown) return;
    this.hudShown = true;
    audio.sfx('whoosh');
    this.tweens.add({ targets: this.bank, y: 6, duration: 550, ease: 'Back.easeOut' });
    this.tweens.add({ targets: [this.speed, this.pauseButton, this.meter, ...extra], alpha: 1, duration: 500, delay: 200 });
  }

  private onPhase(phase: Phase): void {
    if (phase === 'victory' || phase === 'defeat') {
      this.tweens.add({ targets: [this.speed, this.pauseButton], alpha: 0, duration: 300 });
      this.speed.setVisible(false);
      this.pauseButton.disableInteractive();
    }
    if (phase === 'defeat') this.tweens.add({ targets: this.bank, y: -130, duration: 400, ease: 'Back.easeIn' });
  }

  private onKey(event: KeyboardEvent): void {
    const s = this.session;
    if (event.code === 'Escape' || event.code === 'Space' || event.code === 'KeyP') {
      if (event.code === 'Escape' && s.tool && !this.pauseMenu) s.selectTool(null);
      else this.togglePause();
      return;
    }
    if (this.pauseMenu || !s.canInteract) return;
    const digit = /^Digit([1-9])$/.exec(event.code);
    if (digit) this.bank.pickSlot(Number(digit[1]) - 1);
    else if (event.code === 'KeyS' || event.code === 'KeyQ') this.bank.toggleShovel();
    else if (event.code === 'KeyF') this.speed.cycle();
  }

  private togglePause(): void {
    if (this.pauseMenu) {
      this.resume();
      return;
    }
    if (this.session.phase !== 'playing') return;
    this.scene.pause(SceneKeys.Game);
    this.pauseMenu = new PauseMenu(this, {
      onResume: () => this.resume(),
      onRestart: () => this.request('restart'),
      onMenu: () => this.request('menu'),
    });
  }

  private resume(): void {
    this.pauseMenu?.close();
    this.pauseMenu = null;
    this.scene.resume(SceneKeys.Game);
  }

  private request(action: SessionRequest): void {
    if (this.scene.isPaused(SceneKeys.Game)) this.scene.resume(SceneKeys.Game);
    this.session.emit('request', action);
  }
}
