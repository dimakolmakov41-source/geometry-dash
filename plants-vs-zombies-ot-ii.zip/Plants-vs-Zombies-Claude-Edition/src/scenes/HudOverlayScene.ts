import Phaser from 'phaser';
import { GAME_WIDTH } from '@/config/constants';
import { SceneKeys } from '@/core/SceneKeys';
import { settings } from '@/core/SettingsManager';
import { textStyle } from '@/ui/theme';
import { BaseScene } from './BaseScene';

/** Глобальный слой поверх всех сцен: счётчик FPS и будущие системные уведомления. */
export class HudOverlayScene extends BaseScene {
  private fps!: Phaser.GameObjects.Text;

  constructor() {
    super(SceneKeys.HudOverlay);
  }

  create(): void {
    this.fps = this.add.text(GAME_WIDTH - 10, 8, '', textStyle(16)).setOrigin(1, 0).setDepth(10);
    this.fps.setVisible(settings.get().showFps);
    this.listen('settings:changed', (s) => this.fps.setVisible(s.showFps));
    this.time.addEvent({
      delay: 250,
      loop: true,
      callback: () => {
        if (this.fps.visible) this.fps.setText(`FPS ${Math.round(this.game.loop.actualFps)}`);
      },
    });
  }
}
