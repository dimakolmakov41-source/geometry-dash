import Phaser from 'phaser';
import { audio } from '@/audio/AudioManager';

/**
 * Базовый интерактивный элемент: наведение, нажатие, звук и «пружинящая» анимация.
 * Визуал кладётся в `content`, а сам контейнер можно свободно двигать и масштабировать
 * анимациями появления — они не конфликтуют с hover-эффектами.
 */
export class Pressable extends Phaser.GameObjects.Container {
  protected readonly content: Phaser.GameObjects.Container;
  protected enabled = true;
  protected hoverScale = 1.06;
  private pressed = false;
  private clickHandler?: () => void;

  constructor(scene: Phaser.Scene, x: number, y: number, width: number, height: number) {
    super(scene, x, y);
    this.content = scene.add.container(0, 0);
    this.add(this.content);
    this.setSize(width, height);
    this.setInteractive({ useHandCursor: true });
    this.on(Phaser.Input.Events.GAMEOBJECT_POINTER_OVER, this.handleOver, this);
    this.on(Phaser.Input.Events.GAMEOBJECT_POINTER_OUT, this.handleOut, this);
    this.on(Phaser.Input.Events.GAMEOBJECT_POINTER_DOWN, this.handleDown, this);
    this.on(Phaser.Input.Events.GAMEOBJECT_POINTER_UP, this.handleUp, this);
    scene.add.existing(this);
  }

  onClick(handler: () => void): this {
    this.clickHandler = handler;
    return this;
  }

  setEnabled(value: boolean): this {
    this.enabled = value;
    if (value) this.setInteractive({ useHandCursor: true });
    else {
      this.disableInteractive();
      this.pressed = false;
      this.content.setScale(1);
    }
    this.onEnabledChanged(value);
    return this;
  }

  /** Короткая тряска — например, при клике по закрытому элементу. */
  shake(): void {
    this.scene.tweens.killTweensOf(this.content);
    this.content.setAngle(0).setScale(1);
    this.scene.tweens.add({
      targets: this.content,
      x: { from: -8, to: 0 },
      duration: 380,
      ease: 'Elastic.easeOut',
      easeParams: [1.2, 0.25],
    });
  }

  protected onEnabledChanged(_enabled: boolean): void {}

  protected onHover(_over: boolean): void {}

  private tweenScale(scale: number, duration: number, ease = 'Back.easeOut'): void {
    this.scene.tweens.add({ targets: this.content, scale, duration, ease });
  }

  private handleOver(): void {
    if (!this.enabled) return;
    audio.sfx('hover');
    this.tweenScale(this.hoverScale, 160);
    this.scene.tweens.add({ targets: this.content, angle: { from: -2.5, to: 0 }, duration: 420, ease: 'Elastic.easeOut' });
    this.onHover(true);
  }

  private handleOut(): void {
    this.pressed = false;
    this.tweenScale(1, 160);
    this.onHover(false);
  }

  private handleDown(): void {
    if (!this.enabled) return;
    this.pressed = true;
    this.tweenScale(0.93, 70, 'Quad.easeOut');
  }

  private handleUp(): void {
    if (!this.pressed || !this.enabled) return;
    this.pressed = false;
    this.tweenScale(this.hoverScale, 180);
    audio.sfx('click');
    this.clickHandler?.();
  }
}
