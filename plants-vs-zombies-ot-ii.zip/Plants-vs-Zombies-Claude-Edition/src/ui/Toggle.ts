import Phaser from 'phaser';
import { audio } from '@/audio/AudioManager';
import { t } from '@/i18n/ru';
import { textStyle } from './theme';

const W = 96;
const H = 42;
const KNOB_R = 16;

/** Переключатель вкл/выкл с анимированным бегунком. */
export class Toggle extends Phaser.GameObjects.Container {
  private value: boolean;
  private readonly bg: Phaser.GameObjects.Graphics;
  private readonly knob: Phaser.GameObjects.Graphics;
  private readonly label: Phaser.GameObjects.Text;

  constructor(scene: Phaser.Scene, x: number, y: number, value: boolean, private readonly onChange: (value: boolean) => void) {
    super(scene, x, y);
    this.value = value;
    this.bg = scene.add.graphics();
    this.label = scene.add.text(0, 0, '', textStyle(15)).setOrigin(0.5);
    this.knob = scene.add.graphics();
    this.knob.fillStyle(0x000000, 0.25).fillCircle(0, 3, KNOB_R);
    this.knob.fillStyle(0xfff8e7, 1).fillCircle(0, 0, KNOB_R);
    this.knob.lineStyle(3, 0x3b2a18, 1).strokeCircle(0, 0, KNOB_R);
    this.add([this.bg, this.label, this.knob]);

    this.setSize(W + 8, H + 8);
    // pointerup, а не pointerdown: полноэкранный режим разрешён только внутри жеста «отпускания».
    this.setInteractive({ useHandCursor: true }).on(Phaser.Input.Events.GAMEOBJECT_POINTER_UP, () => {
      audio.sfx('toggle');
      this.setValue(!this.value, true);
      this.onChange(this.value);
    });
    this.setValue(value, false);
    scene.add.existing(this);
  }

  setValue(value: boolean, animate: boolean): this {
    this.value = value;
    const knobX = value ? W / 2 - KNOB_R - 5 : -W / 2 + KNOB_R + 5;
    this.scene.tweens.killTweensOf(this.knob);
    if (animate) this.scene.tweens.add({ targets: this.knob, x: knobX, duration: 220, ease: 'Back.easeOut' });
    else this.knob.x = knobX;

    this.bg.clear();
    this.bg.fillStyle(0x3b2a18, 1).fillRoundedRect(-W / 2 - 3, -H / 2 - 3, W + 6, H + 6, (H + 6) / 2);
    this.bg.fillStyle(value ? 0x5fbf2e : 0x8a7a66, 1).fillRoundedRect(-W / 2, -H / 2, W, H, H / 2);
    this.bg.fillStyle(0xffffff, 0.2).fillRoundedRect(-W / 2 + 6, -H / 2 + 4, W - 12, H * 0.35, 8);
    this.label.setText(value ? t.settings.on : t.settings.off);
    this.label.x = value ? -14 : 14;
    return this;
  }
}
