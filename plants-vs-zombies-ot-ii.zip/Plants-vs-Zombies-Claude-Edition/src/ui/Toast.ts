import Phaser from 'phaser';
import { CENTER_X } from '@/config/constants';
import { textStyle } from './theme';

/** Короткое всплывающее сообщение сверху экрана. */
export function showToast(scene: Phaser.Scene, message: string, duration = 1800): void {
  const text = scene.add.text(0, 0, message, textStyle(22)).setOrigin(0.5);
  const w = text.width + 48;
  const h = 52;
  const bg = scene.add.graphics();
  bg.fillStyle(0x000000, 0.25).fillRoundedRect(-w / 2, -h / 2 + 5, w, h, 16);
  bg.fillStyle(0x3b2a18, 0.92).fillRoundedRect(-w / 2, -h / 2, w, h, 16);
  bg.lineStyle(3, 0xffd23f, 1).strokeRoundedRect(-w / 2 + 2, -h / 2 + 2, w - 4, h - 4, 14);
  const toast = scene.add.container(CENTER_X, -40, [bg, text]).setDepth(2000);

  scene.tweens.chain({
    targets: toast,
    tweens: [
      { y: 44, duration: 320, ease: 'Back.easeOut' },
      { y: -40, duration: 260, ease: 'Back.easeIn', delay: duration },
    ],
    onComplete: () => toast.destroy(),
  });
}
