import Phaser from 'phaser';
import { ensureButtonTexture, ensureRoundButtonTexture, type ButtonVariant } from '@/graphics/textures/ui';
import { Pressable } from './Pressable';
import { textStyle } from './theme';

export interface ButtonConfig {
  label: string;
  width?: number;
  height?: number;
  variant?: ButtonVariant;
  fontSize?: number;
  icon?: string;
}

export class Button extends Pressable {
  private readonly glow: Phaser.GameObjects.Image;
  private readonly label: Phaser.GameObjects.Text;
  private readonly icon?: Phaser.GameObjects.Image;

  constructor(scene: Phaser.Scene, x: number, y: number, config: ButtonConfig) {
    const width = config.width ?? 320;
    const height = config.height ?? 68;
    super(scene, x, y, width, height);

    const tex = ensureButtonTexture(scene.textures, config.variant ?? 'wood', width, height);
    const bg = scene.add.image(0, 0, tex.key).setOrigin(tex.originX, tex.originY);
    this.glow = scene.add
      .image(0, 0, tex.key)
      .setOrigin(tex.originX, tex.originY)
      .setBlendMode(Phaser.BlendModes.ADD)
      .setAlpha(0);
    const fontSize = config.fontSize ?? Math.round(height * 0.4);
    this.label = scene.add.text(0, -3, config.label, textStyle(fontSize)).setOrigin(0.5);
    this.content.add([bg, this.glow, this.label]);

    if (config.icon) {
      const size = fontSize * 1.2;
      this.icon = scene.add.image(0, -3, config.icon).setDisplaySize(size, size);
      this.content.add(this.icon);
    }
    this.layout();
  }

  setLabel(text: string): this {
    this.label.setText(text);
    this.layout();
    return this;
  }

  protected override onHover(over: boolean): void {
    this.scene.tweens.add({ targets: this.glow, alpha: over ? 0.16 : 0, duration: 160 });
  }

  protected override onEnabledChanged(enabled: boolean): void {
    this.setAlpha(enabled ? 1 : 0.5);
  }

  private layout(): void {
    if (!this.icon) {
      this.label.x = 0;
      return;
    }
    const gap = 12;
    const total = this.icon.displayWidth + gap + this.label.width;
    this.icon.x = -total / 2 + this.icon.displayWidth / 2;
    this.label.x = this.icon.x + this.icon.displayWidth / 2 + gap + this.label.width / 2;
  }
}

export class RoundButton extends Pressable {
  constructor(scene: Phaser.Scene, x: number, y: number, icon: string, options: { size?: number; variant?: ButtonVariant } = {}) {
    const size = options.size ?? 64;
    super(scene, x, y, size, size);
    this.hoverScale = 1.1;
    const tex = ensureRoundButtonTexture(scene.textures, options.variant ?? 'wood', size);
    const bg = scene.add.image(0, 0, tex.key).setOrigin(tex.originX, tex.originY);
    const iconImage = scene.add.image(0, -3, icon).setDisplaySize(size * 0.55, size * 0.55);
    this.content.add([bg, iconImage]);
  }
}
