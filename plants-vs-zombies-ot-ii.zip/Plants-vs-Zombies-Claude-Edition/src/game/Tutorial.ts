import type { PlantId } from '@/data/plants';
import { t } from '@/i18n/ru';
import type { LevelSession } from './LevelSession';

/** Подсказка уровня: показывается, только если нужное растение уже есть у игрока. */
const LEVEL_HINTS: Record<string, { text: string; requires?: PlantId }> = {
  '1-2': { text: t.tutorial.sunflower },
  '1-3': { text: t.tutorial.cherry, requires: 'cherrybomb' },
  '1-4': { text: t.tutorial.fiveRows },
  '1-5': { text: t.tutorial.wallnut, requires: 'wallnut' },
  '1-6': { text: t.tutorial.potato, requires: 'potatomine' },
  '1-7': { text: t.tutorial.snowpea, requires: 'snowpea' },
  '1-8': { text: t.tutorial.chomper, requires: 'chomper' },
  '1-9': { text: t.tutorial.bucket },
  '1-10': { text: t.tutorial.repeater, requires: 'repeater' },
};

/** Подсказки уровней; 1-1 — пошаговое обучение. */
export function startTutorial(session: LevelSession, scheduleHide: (sec: number) => void): void {
  if (session.level.id === '1-1') {
    session.hint(t.tutorial.pick);
    const onTool = () => {
      if (session.tool?.kind !== 'plant') return;
      session.off('tool-changed', onTool);
      session.hint(t.tutorial.place);
    };
    session.on('tool-changed', onTool);
    session.once('planted', () => {
      session.off('tool-changed', onTool);
      session.hint(t.tutorial.collect);
      scheduleHide(7);
    });
    return;
  }
  const hint = LEVEL_HINTS[session.level.id];
  if (!hint) return;
  if (hint.requires && !(session.plants as PlantId[]).includes(hint.requires)) return;
  session.hint(hint.text);
  scheduleHide(9);
}
