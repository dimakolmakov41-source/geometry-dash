import type { PlantId } from '@/data/plants';

/** Все числа баланса в одном месте. */
export const SUN_VALUE = 25;
export const SUN_FALL_SPEED = 62;
export const SUN_LIFETIME = 10;

export const PEA = { speed: 400, damage: 20 } as const;
export const EAT = { dps: 100, biteInterval: 0.5 } as const;
/** Замедление от снежного гороха: скорость и темп укусов умножаются на factor. */
export const CHILL = { duration: 10, factor: 0.5 } as const;
export const MOWER_SPEED = 640;
export const ZOMBIE_SCALE = 0.62;

export const PLANT_STATS = {
  peashooter: { hp: 300, fireInterval: 1.4 },
  sunflower: { hp: 300, firstSunMin: 4, firstSunMax: 9, interval: 24 },
  cherrybomb: { hp: 3000, fuse: 1.1, damage: 1800, radiusCols: 1.5 },
  wallnut: { hp: 4000 },
  potatomine: { hp: 300, armTime: 14, damage: 1800, radius: 70 },
  snowpea: { hp: 300, fireInterval: 1.4 },
  chomper: { hp: 300, reachCols: 1.3, biteDelay: 0.45, chewTime: 42 },
  repeater: { hp: 300, fireInterval: 1.4, burstGap: 0.16 },
} as const;

export type PlayablePlant = keyof typeof PLANT_STATS;

export const isPlayable = (id: PlantId): id is PlayablePlant => id in PLANT_STATS;

/** Растения, которые в начале уровня ещё перезаряжаются (секунды). */
export const INITIAL_COOLDOWN: Partial<Record<PlayablePlant, number>> = { cherrybomb: 25, wallnut: 15, potatomine: 15 };

export const MAX_SEED_SLOTS = 8;
