import Phaser from 'phaser';
import { CENTER_X, CENTER_Y, GAME_HEIGHT, GAME_WIDTH } from '@/config/constants';
import { audio } from '@/audio/AudioManager';
import { PLANTS } from '@/data/plants';
import { Tex } from '@/graphics/TextureKeys';
import { ensurePanelTexture } from '@/graphics/textures/ui';
import { t } from '@/i18n/ru';
import { Button } from '@/ui/Button';
import { inkStyle, textStyle } from '@/ui/theme';
import type { LevelResult, SessionRequest } from '../LevelSession';
import { createPacketView } from '../view/plantVisuals';

const W = 640;

/** Итоги уровня: победа (звёзды и новое растение) или поражение. */
export class ResultPanel extends Phaser.GameObjects.Container {
  constructor(scene: Phaser.Scene, result: LevelResult, request: (action: SessionRequest) => void) {
    super(scene, 0, 0);
    this.setDepth(950);
    const overlay = scene.add.rectangle(0, 0, GAME_WIDTH, GAME_HEIGHT, 0x0a1405, 1).setOrigin(0).setAlpha(0).setInteractive();
    const H = result.victory ? (result.newPlant ? 520 : 400) : 380;
    const tex = ensurePanelTexture(scene.textures, result.victory ? 'paper' : 'wood', W, H);
    const top = -H / 2;
    const box = scene.add.container(CENTER_X, CENTER_Y, [scene.add.image(0, 0, tex.key).setOrigin(tex.originX, tex.originY)]);

    if (result.victory) this.buildVictory(scene, box, top, H, result, request);
    else this.buildDefeat(scene, box, top, H, request);

    this.add([overlay, box]);
    scene.add.existing(this);
    scene.tweens.add({ targets: overlay, alpha: 0.55, duration: 300 });
    box.setScale(0.6).setAlpha(0);
    scene.tweens.add({ targets: box, scale: 1, alpha: 1, duration: 420, ease: 'Back.easeOut' });
  }

  private buildVictory(
    scene: Phaser.Scene,
    box: Phaser.GameObjects.Container,
    top: number,
    h: number,
    result: LevelResult,
    request: (action: SessionRequest) => void,
  ): void {
    const title = scene.add.text(0, top + 56, t.game.victory, textStyle(60, { color: '#ffd23f' })).setOrigin(0.5);
    box.add(title);
    scene.tweens.add({ targets: title, scale: { from: 1, to: 1.06 }, yoyo: true, repeat: -1, duration: 700, ease: 'Sine.easeInOut' });

    for (let i = 0; i < 3; i++) {
      const x = (i - 1) * 84;
      const y = top + 138 - (i === 1 ? 10 : 0);
      box.add(scene.add.image(x, y, Tex.Ui.StarEmpty).setScale(1.25));
      if (i >= result.stars) continue;
      const star = scene.add.image(x, y, Tex.Ui.Star).setScale(0);
      box.add(star);
      scene.tweens.add({
        targets: star,
        scale: 1.25,
        delay: 450 + i * 280,
        duration: 380,
        ease: 'Back.easeOut',
        onStart: () => audio.sfx('sun'),
      });
    }
    box.add(scene.add.text(0, top + 196, t.game.mowers(result.mowersUsed), inkStyle(19)).setOrigin(0.5));

    if (result.newPlant) {
      const plant = PLANTS[result.newPlant];
      const packet = createPacketView(scene, result.newPlant).setPosition(-170, top + 300).setScale(1.3);
      box.add([
        packet,
        scene.add.text(-110, top + 262, t.game.newPlant, textStyle(26, { color: '#8fe03c' })).setOrigin(0, 0.5),
        scene.add.text(-110, top + 300, plant.name, inkStyle(26, { fontStyle: '900' })).setOrigin(0, 0.5),
        scene.add.text(-110, top + 334, plant.description, inkStyle(18, { color: '#6b5236' })).setOrigin(0, 0.5),
      ]);
      scene.tweens.add({ targets: packet, angle: { from: -5, to: 5 }, yoyo: true, repeat: -1, duration: 900, ease: 'Sine.easeInOut' });
    }

    const y = top + h - 66;
    const primary = result.nextLevelId
      ? { label: t.game.next, action: 'next' as const }
      : { label: t.game.toLevels, action: 'levels' as const };
    box.add([
      new Button(scene, -200, y, { label: t.game.toMenu, width: 170, height: 60, fontSize: 22 }).onClick(() => request('menu')),
      new Button(scene, -10, y, { label: t.game.retry, icon: Tex.Icon.Restart, width: 180, height: 60, fontSize: 22 }).onClick(() =>
        request('restart'),
      ),
      new Button(scene, 195, y, { label: primary.label, icon: Tex.Icon.Play, variant: 'green', width: 190, height: 60, fontSize: 24 }).onClick(
        () => request(primary.action),
      ),
    ]);
  }

  private buildDefeat(
    scene: Phaser.Scene,
    box: Phaser.GameObjects.Container,
    top: number,
    h: number,
    request: (action: SessionRequest) => void,
  ): void {
    const head = scene.add.image(0, top + 96, Tex.Zombie.Head).setScale(1.1);
    scene.tweens.add({ targets: head, angle: { from: -8, to: 8 }, yoyo: true, repeat: -1, duration: 500, ease: 'Sine.easeInOut' });
    box.add([
      head,
      scene.add.text(0, top + 176, t.game.lostTitle, textStyle(44, { color: '#b6e36a' })).setOrigin(0.5),
      scene.add.text(0, top + 236, t.game.lostText, textStyle(20, { align: 'center', fontStyle: '700', strokeThickness: 4 })).setOrigin(0.5),
      new Button(scene, -120, top + h - 66, { label: t.game.toMenu, width: 200, height: 62, fontSize: 24 }).onClick(() => request('menu')),
      new Button(scene, 120, top + h - 66, { label: t.game.retry, icon: Tex.Icon.Restart, variant: 'green', width: 220, height: 62 }).onClick(
        () => request('restart'),
      ),
    ]);
  }
}
