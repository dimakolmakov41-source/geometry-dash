import Phaser from 'phaser';
import { CENTER_X, CENTER_Y, GAME_HEIGHT, GAME_WIDTH } from '@/config/constants';
import { settings } from '@/core/SettingsManager';
import { audio } from '@/audio/AudioManager';
import { Tex } from '@/graphics/TextureKeys';
import { ensurePanelTexture } from '@/graphics/textures/ui';
import { t } from '@/i18n/ru';
import { Button } from '@/ui/Button';
import { Slider } from '@/ui/Slider';
import { textStyle } from '@/ui/theme';

export interface PauseMenuHandlers {
  onResume: () => void;
  onRestart: () => void;
  onMenu: () => void;
}

const W = 520;
const H = 520;

/** Меню паузы: громкость, продолжить, заново, в меню и подсказка по клавишам. */
export class PauseMenu extends Phaser.GameObjects.Container {
  private readonly box: Phaser.GameObjects.Container;
  private readonly overlay: Phaser.GameObjects.Rectangle;

  constructor(scene: Phaser.Scene, handlers: PauseMenuHandlers) {
    super(scene, 0, 0);
    this.setDepth(900);
    this.overlay = scene.add.rectangle(0, 0, GAME_WIDTH, GAME_HEIGHT, 0x0a1405, 1).setOrigin(0).setAlpha(0).setInteractive();
    const tex = ensurePanelTexture(scene.textures, 'wood', W, H);
    const top = -H / 2;
    const s = settings.get();
    const items: Phaser.GameObjects.GameObject[] = [
      scene.add.image(0, 0, tex.key).setOrigin(tex.originX, tex.originY),
      scene.add.text(0, top + 54, t.game.pause, textStyle(46)).setOrigin(0.5),
      scene.add.text(-200, top + 124, t.settings.music, textStyle(22)).setOrigin(0, 0.5),
      new Slider(scene, 70, top + 124, { width: 170, value: s.musicVolume, onChange: (v) => settings.set('musicVolume', v) }),
      scene.add.text(-200, top + 178, t.settings.sfx, textStyle(22)).setOrigin(0, 0.5),
      new Slider(scene, 70, top + 178, {
        width: 170,
        value: s.sfxVolume,
        onChange: (v) => settings.set('sfxVolume', v),
        onRelease: () => audio.sfx('sun'),
      }),
      new Button(scene, 0, top + 262, { label: t.game.resume, icon: Tex.Icon.Play, variant: 'green', width: 300, height: 66 }).onClick(
        handlers.onResume,
      ),
      new Button(scene, 0, top + 340, { label: t.game.restart, icon: Tex.Icon.Restart, width: 300, height: 58, fontSize: 24 }).onClick(
        handlers.onRestart,
      ),
      new Button(scene, 0, top + 410, { label: t.game.toMenu, icon: Tex.Icon.Back, width: 300, height: 58, fontSize: 24 }).onClick(
        handlers.onMenu,
      ),
      scene.add.text(0, top + 472, t.game.hotkeys, textStyle(13, { strokeThickness: 3 })).setOrigin(0.5).setAlpha(0.85),
    ];
    this.box = scene.add.container(CENTER_X, CENTER_Y, items);
    this.add([this.overlay, this.box]);
    scene.add.existing(this);

    audio.sfx('whoosh');
    scene.tweens.add({ targets: this.overlay, alpha: 0.6, duration: 200 });
    this.box.setScale(0.7).setAlpha(0);
    scene.tweens.add({ targets: this.box, scale: 1, alpha: 1, duration: 300, ease: 'Back.easeOut' });
  }

  close(): void {
    this.overlay.disableInteractive();
    this.scene.tweens.add({ targets: this.overlay, alpha: 0, duration: 160 });
    this.scene.tweens.add({ targets: this.box, scale: 0.7, alpha: 0, duration: 160, ease: 'Back.easeIn', onComplete: () => this.destroy() });
  }
}
