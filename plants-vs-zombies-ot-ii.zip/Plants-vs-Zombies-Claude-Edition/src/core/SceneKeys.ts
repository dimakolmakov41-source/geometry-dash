export const SceneKeys = {
  Boot: 'Boot',
  Preload: 'Preload',
  MenuBackground: 'MenuBackground',
  MainMenu: 'MainMenu',
  LevelSelect: 'LevelSelect',
  Saves: 'Saves',
  Settings: 'Settings',
  Game: 'Game',
  GameHud: 'GameHud',
  HudOverlay: 'HudOverlay',
} as const;

export type SceneKey = (typeof SceneKeys)[keyof typeof SceneKeys];

/** Ключи общего реестра Phaser (game.registry). */
export const RegistryKeys = {
  MenuWorld: 'menu:world',
} as const;
