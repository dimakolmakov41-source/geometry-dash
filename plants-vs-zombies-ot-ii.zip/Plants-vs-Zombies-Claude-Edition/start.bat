@echo off
chcp 65001 >nul
title Растения против Зомби
cd /d "%~dp0"

echo.
echo   ===========================================
echo      Растения против Зомби
echo   ===========================================
echo.

where node >nul 2>nul
if errorlevel 1 (
  echo   [ОШИБКА] Node.js не найден.
  echo   Установите его с https://nodejs.org и запустите этот файл снова.
  echo.
  pause
  exit /b 1
)

if not exist "node_modules" (
  echo   Первый запуск: устанавливаю зависимости...
  echo.
  call npm install
  if errorlevel 1 (
    echo.
    echo   [ОШИБКА] Не удалось установить зависимости.
    pause
    exit /b 1
  )
)

echo   Запускаю игру. Браузер откроется автоматически.
echo   Если не открылся, перейдите по адресу: http://127.0.0.1:5173
echo   Чтобы остановить сервер, закройте это окно или нажмите Ctrl+C.
echo.
call npm run dev -- --open

if errorlevel 1 (
  echo.
  echo   [ОШИБКА] Сервер завершился с ошибкой.
  pause
)
